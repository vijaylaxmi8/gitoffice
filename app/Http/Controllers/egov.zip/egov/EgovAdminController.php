<?php

namespace App\Http\Controllers\egov;

use App\Http\Controllers\Controller;

use App\Enums\UserRoles;
use App\Models\users;
use App\Models\staff;
use App\Models\user;
use App\Models\professional_activity_attendee;
use App\Models\professional_activity_conducted;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Session;
use Hash;
use Auth;


class EgovAdminController extends Controller
{

    public function dashboard()
    {
        
        return view('egov.dashboard');
    }

    public function egov_professional_activity_attended_teaching(Request $request)
    {
        
        $department_id=Session ::get('deptid');
       // dd($department_id);
        $professional_activity_attendee=DB::table('professional_activity_attendees')
                                            ->join('professional_activity_attendee_staff','professional_activity_attendee_id','=','professional_activity_attendees.id')
                                            ->join('staff','staff.id','=','professional_activity_attendee_staff.staff_id')
                                            ->join('department_staff','department_staff.staff_id','=','staff.id')
                                            ->join('departments','departments.id','=','department_staff.department_id')
                                            ->where('staff.employee_type','=','Teaching')
                                            ->where('department_id','=',$department_id)
                                            ->select('professional_activity_attendees.*','fname','staff.id','mname','lname','employee_type','department_id','dept_shortname','organizer','sponsored','sponsored_by')
                                            ->get();
        // dd($professional_activity_attendee);
    
        return view('/egov/Teaching/activityattended',compact(['professional_activity_attendee']));
    }

    public function egov_professional_activity_conducted_teaching(Request $request)
    {
      
        $department_id=Session ::get('deptid');
        $professional_activity_conducteds=DB::table('professional_activity_conducteds')
                                            ->join('professional_activity_conducted_staff','professional_activity_conducted_id','=','professional_activity_conducteds.id')
                                            ->join('staff','staff.id','=','professional_activity_conducted_staff.staff_id')
                                            ->join('department_staff','department_staff.staff_id','=','staff.id')
                                            ->join('departments','departments.id','=','department_staff.department_id')
                                            ->where('staff.employee_type','=','Teaching')
                                            ->where('department_id','=',$department_id)
                                            ->select('professional_activity_conducteds.*','fname','staff.id','mname','lname','employee_type','department_id','dept_shortname','sponsoring_agency_name_address')
                                            ->get();
        // dd($professional_activity_conducteds);
    
        return view('/egov/Teaching/activityconducted',compact(['professional_activity_conducteds']));
    }

    public function egov_professional_activity_attendee_nt(Request $request)
    {
        
        $department_id=Session ::get('deptid');
        $professional_activity_attendee=DB::table('professional_activity_attendees')
                                            ->join('professional_activity_attendee_staff','professional_activity_attendee_id','=','professional_activity_attendees.id')
                                            ->join('staff','staff.id','=','professional_activity_attendee_staff.staff_id')
                                            ->join('department_staff','department_staff.staff_id','=','staff.id')
                                            ->join('departments','departments.id','=','department_staff.department_id')
                                            ->where('staff.employee_type','=','Non-teaching')
                                            ->where('department_id','=',$department_id)
                                            ->select('professional_activity_attendees.*','fname','staff.id','mname','lname','employee_type','department_id','dept_shortname','organizer','sponsored','sponsored_by')
                                            ->get();
         //dd($professional_activity_attendee);
    
        return view('/egov/Non-Teaching/attended',compact(['professional_activity_attendee']));
    }

    public function egov_professional_activity_conducted_nt(Request $request)
    {
      
        $department_id=Session ::get('deptid');
        $professional_activity_conducteds=DB::table('professional_activity_conducteds')
                                            ->join('professional_activity_conducted_staff','professional_activity_conducted_id','=','professional_activity_conducteds.id')
                                            ->join('staff','staff.id','=','professional_activity_conducted_staff.staff_id')
                                            ->join('department_staff','department_staff.staff_id','=','staff.id')
                                            ->join('departments','departments.id','=','department_staff.department_id')
                                            ->where('staff.employee_type','=','Non-teaching')
                                            ->where('department_id','=',$department_id)
                                            ->select('professional_activity_conducteds.*','fname','staff.id','mname','lname','employee_type','department_id','dept_shortname','sponsoring_agency_name_address')
                                            ->get();
        // dd($professional_activity_conducteds);
    
        return view('/egov/Non-Teaching/conducted',compact(['professional_activity_conducteds']));
    }
    
}

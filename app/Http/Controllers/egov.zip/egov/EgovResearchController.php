<?php

namespace App\Http\Controllers\egov;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Enums\UserRoles;
use App\Models\staff;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\conferences_attendee;
use App\Models\conferences_conducted;
use App\Models\publication;
use App\Models\funded_project;
use App\Models\patent;
use App\Models\copyright;
use App\Models\general_achievements;
use Session;
use Hash;
use Auth;

class EgovResearchController extends Controller
{
    //
    public function egov_conferences_attendee(Request $request)
    {
        
        $department_id=Session ::get('deptid');
        $conferences_attendees=DB::table('conferences_attendees')
                                            ->join('conferences_attendee_staff','conferences_attendee_id','=','conferences_attendees.id')
                                            ->join('staff','staff.id','=','conferences_attendee_staff.staff_id')
                                            ->join('department_staff','department_staff.staff_id','=','staff.id')
                                            ->join('departments','departments.id','=','department_staff.department_id')
                                            ->where('staff.employee_type','=','Teaching')
                                            ->where('department_id','=',$department_id)
                                            ->select('conferences_attendees.*','fname','staff.id','mname','lname','employee_type','department_id','dept_shortname',)
                                            ->get();
         //dd($conferences_attendees);
    
        return view('/egov/Teaching/research/conferenceattended',compact(['conferences_attendees']));
    }

    public function egov_conferences_conducted(Request $request)
    {
        
        $department_id=Session ::get('deptid');
        $conferences_conducted=DB::table('conferences_conducteds')
                                            ->join('conferences_conducted_staff','conferences_conducted_id','=','conferences_conducteds.id')
                                            ->join('staff','staff.id','=','conferences_conducted_staff.staff_id')
                                            ->join('department_staff','department_staff.staff_id','=','staff.id')
                                            ->join('departments','departments.id','=','department_staff.department_id')
                                            ->where('staff.employee_type','=','Teaching')
                                            ->where('department_id','=',$department_id)
                                            ->select('conferences_conducteds.*','fname','staff.id','mname','lname','employee_type','department_id','dept_shortname',)
                                            ->get();
         //dd($conferences_attendees);
    
        return view('/egov/Teaching/research/conferenceconducted',compact(['conferences_conducted']));
    }

    public function egov_publication(Request $request)
    {
        
        $department_id=Session ::get('deptid');
        $publication=DB::table('publications')
                                    ->join('staff','staff.id','=','publications.staff_id')
                                    ->join('department_staff','department_staff.staff_id','=','staff.id')
                                    ->join('departments','departments.id','=','department_staff.department_id')
                                    ->where('staff.employee_type','=','Teaching')
                                    ->where('department_id','=',$department_id)
                                    ->select('publications.*','fname','staff.id','mname','lname','employee_type','department_id','dept_shortname',)
                                    ->get();
                                           
                                           
        // dd($publication);
    
        return view('/egov/Teaching/research/publication',compact(['publication']));
    }

    public function egov_funded_project(Request $request)
    {
        
        $department_id=Session ::get('deptid');
        $fundedproject=DB::table('funded_projects')
                                           
                                    ->join('staff','staff.id','=','funded_projects.staff_id')
                                    ->join('department_staff','department_staff.staff_id','=','staff.id')
                                    ->join('departments','departments.id','=','department_staff.department_id')
                                    ->where('staff.employee_type','=','Teaching')
                                    ->where('department_id','=',$department_id)
                                    ->select('funded_projects.*','fname','staff.id','mname','lname','employee_type','department_id','dept_shortname',)
                                    ->get();
        // dd($fundedproject);
    
        return view('/egov/Teaching/research/fundedproject',compact(['fundedproject']));
    }

    public function egov_patents(Request $request)
    {
        
        $department_id=Session ::get('deptid');
        $patents=DB::table('patents')
                                           
                        ->join('staff','staff.id','=','patents.staff_id')
                        ->join('department_staff','department_staff.staff_id','=','staff.id')
                        ->join('departments','departments.id','=','department_staff.department_id')
                        ->where('staff.employee_type','=','Teaching')
                        ->where('department_id','=',$department_id)
                        ->select('patents.*','fname','staff.id','mname','lname','employee_type','department_id','dept_shortname',)
                        ->get();
        // dd($patents);
    
        return view('/egov/Teaching/research/patents',compact(['patents']));
    }
    public function egov_copyrights(Request $request)
    {
        
        $department_id=Session ::get('deptid');
        $copyrights=DB::table('copyrights')
                                           
                            ->join('staff','staff.id','=','copyrights.staff_id')
                            ->join('department_staff','department_staff.staff_id','=','staff.id')
                            ->join('departments','departments.id','=','department_staff.department_id')
                            ->where('staff.employee_type','=','Teaching')
                            ->where('department_id','=',$department_id)
                            ->select('copyrights.*','fname','staff.id','mname','lname','employee_type','department_id','dept_shortname',)
                            ->get();
                        //  dd($copyrights);
    
        return view('/egov/Teaching/research/copyrights',compact(['copyrights']));
    }

    public function egov_general_achievement(Request $request)
    {
        
        $department_id=Session ::get('deptid');
        $general_achievements=DB::table('general_achievements')
                                           
                            ->join('staff','staff.id','=','general_achievements.staff_id')
                            ->join('department_staff','department_staff.staff_id','=','staff.id')
                            ->join('departments','departments.id','=','department_staff.department_id')
                            ->where('staff.employee_type','=','Teaching')
                            ->where('department_id','=',$department_id)
                            ->select('general_achievements.*','fname','staff.id','mname','lname','employee_type','department_id','dept_shortname',)
                            ->get();
                        
    
        return view('/egov/Teaching/research/achivements',compact(['general_achievements']));
    }


}
